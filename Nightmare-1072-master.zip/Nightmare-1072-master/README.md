# Nightmare-1072
A BFS variant

the problem link: http://acm.hdu.edu.cn/showproblem.php?pid=1072
